MEMBRES DU GROUPE

Serkan SAHIN
Lana HUDABAIDI
Joel HOUENOU
Kinty DIALLO
Ruben VANYPER


SITE DE VOYAGE

Nom: PARIS A TOUT PRIX

Cible: Touristes et voyageurs desirant se rendre a Paris

Activités:Le site propose des bons plans d'hôtels sur Paris et des vols aux meilleurs prix

surge : inseec-landingpage-voyage.surge.sh